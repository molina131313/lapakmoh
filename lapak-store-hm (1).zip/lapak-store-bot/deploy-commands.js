require('dotenv').config();
const { REST, Routes, SlashCommandBuilder } = require('discord.js');

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID; // opsional, kosongkan untuk global

if (!token) throw new Error('DISCORD_TOKEN tidak ditemukan di file .env');
if (!clientId) throw new Error('CLIENT_ID tidak ditemukan di file .env');

const commands = [
  new SlashCommandBuilder()
    .setName('panel')
    .setDescription('Tampilkan panel produk Lapak Store ID')
    .toJSON(),
];

const rest = new REST().setToken(token);

(async () => {
  try {
    console.log('Mendaftarkan slash commands...');

    if (guildId) {
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(`✅ Commands terdaftar di guild: ${guildId}`);
    } else {
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log('✅ Commands terdaftar secara global (tunggu hingga 1 jam).');
    }
  } catch (error) {
    console.error(error);
  }
})();
