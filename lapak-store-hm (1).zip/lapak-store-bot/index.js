require('dotenv').config();
const fs = require('fs');
const path = require('path');
const http = require('http');
const {
  Client,
  GatewayIntentBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  EmbedBuilder,
  PermissionsBitField,
  ChannelType,
} = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// CONFIG
const CATEGORY_ID = '1486571964679192666';
const ROLE_1 = '1486199433795473488';
const ROLE_2 = '1486197937926049922';
const LOG_CHANNEL = '1486578252318511234';
const VOUCH_CHANNEL = '1486576403830013963';
const QRIS_IMAGE =
  'https://cdn.discordapp.com/attachments/1489661125397053460/1489661331304091810/IMG-20260326-WA0066.jpg?ex=69d13ab9&is=69cfe939&hm=ccb9c55f66ebabe79c9dcaab14487942f7baf1116234456e198e85a10f41e248&';

const ORDER_FILE = path.join(__dirname, 'order.json');

// ORDER ID
function getOrderNumber() {
  const data = JSON.parse(fs.readFileSync(ORDER_FILE, 'utf-8'));
  data.order += 1;
  fs.writeFileSync(ORDER_FILE, JSON.stringify(data, null, 2));
  return data.order.toString().padStart(4, '0');
}

// MODAL DEFINITIONS
const modals = {
  vilog_robux: new ModalBuilder()
    .setCustomId('modal_vilog_robux')
    .setTitle('🎮 Vilog Robux')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('username')
          .setLabel('Username Roblox')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('password')
          .setLabel('Password Roblox')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('backup_code')
          .setLabel('Backup Code (minimal 3 kode)')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Pisahkan dengan koma, contoh: ABC123, DEF456, GHI789')
          .setRequired(true)
      )
    ),

  robux_pending: new ModalBuilder()
    .setCustomId('modal_robux_pending')
    .setTitle('⏳ Robux Pending')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('username')
          .setLabel('Username Roblox')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('total_robux')
          .setLabel('Total Robux')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Contoh: 1000')
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('tax_type')
          .setLabel('After Tax / Before Tax')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Ketik: aftertax atau beforetax')
          .setRequired(true)
      )
    ),

  gift_roblox: new ModalBuilder()
    .setCustomId('modal_gift_roblox')
    .setTitle('🎁 Gift In Game Roblox')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('username')
          .setLabel('Username / Nickname')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('map_name')
          .setLabel('Nama Map')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('total_robux')
          .setLabel('Total Robux')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Contoh: 500')
          .setRequired(true)
      )
    ),

  topup_ff: new ModalBuilder()
    .setCustomId('modal_topup_ff')
    .setTitle('🔥 Top Up Free Fire')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('nickname')
          .setLabel('Nickname FF')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('player_id')
          .setLabel('ID Player FF')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('product_name')
          .setLabel('Nama Produk')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Contoh: 100 Diamond, Weekly Pass')
          .setRequired(true)
      )
    ),

  topup_ml: new ModalBuilder()
    .setCustomId('modal_topup_ml')
    .setTitle('⚡ Top Up Mobile Legends')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('id_server')
          .setLabel('ID (Server)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Contoh: 123456789 (1234)')
          .setRequired(true)
      )
    ),

  vilog_ml: new ModalBuilder()
    .setCustomId('modal_vilog_ml')
    .setTitle('💎 Vilog Mobile Legends')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('email')
          .setLabel('Email Moonton')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('password')
          .setLabel('Sandi Moonton')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('total_diamond')
          .setLabel('Total Diamond')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Contoh: 500')
          .setRequired(true)
      )
    ),
};

// DETAIL FIELDS PER MODAL
function getOrderFields(modalId, fields) {
  switch (modalId) {
    case 'modal_vilog_robux':
      return [
        { name: '👤 Username', value: fields.username, inline: true },
        { name: '🔑 Password', value: fields.password, inline: true },
        { name: '🔐 Backup Code', value: fields.backup_code, inline: false },
      ];
    case 'modal_robux_pending':
      return [
        { name: '👤 Username', value: fields.username, inline: true },
        { name: '💸 Total Robux', value: fields.total_robux, inline: true },
        { name: '🏷️ Tipe', value: fields.tax_type, inline: true },
      ];
    case 'modal_gift_roblox':
      return [
        { name: '👤 Username / Nickname', value: fields.username, inline: true },
        { name: '🗺️ Nama Map', value: fields.map_name, inline: true },
        { name: '💸 Total Robux', value: fields.total_robux, inline: true },
      ];
    case 'modal_topup_ff':
      return [
        { name: '🎮 Nickname', value: fields.nickname, inline: true },
        { name: '🆔 ID Player', value: fields.player_id, inline: true },
        { name: '📦 Produk', value: fields.product_name, inline: false },
      ];
    case 'modal_topup_ml':
      return [{ name: '🆔 ID (Server)', value: fields.id_server, inline: true }];
    case 'modal_vilog_ml':
      return [
        { name: '📧 Email Moonton', value: fields.email, inline: true },
        { name: '🔑 Sandi Moonton', value: fields.password, inline: true },
        { name: '💎 Total Diamond', value: fields.total_diamond, inline: true },
      ];
    default:
      return [];
  }
}

// PRODUCT NAMES
const PRODUCT_NAMES = {
  modal_vilog_robux: '🎮 Vilog Robux',
  modal_robux_pending: '⏳ Robux Pending',
  modal_gift_roblox: '🎁 Gift In Game Roblox',
  modal_topup_ff: '🔥 Top Up Free Fire',
  modal_topup_ml: '⚡ Top Up Mobile Legends',
  modal_vilog_ml: '💎 Vilog ML',
};

client.once('clientReady', (readyClient) => {
  console.log(`Login sebagai ${readyClient.user.tag}`);
});

// ================= !nominal <harga> =================
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const allowedRoles = [ROLE_1, ROLE_2];
  const isAdmin = message.member?.roles.cache.some((r) => allowedRoles.includes(r.id));
  if (!isAdmin) return;

  const args = message.content.trim().split(/\s+/);
  if (args[0].toLowerCase() !== '!nominal') return;

  const harga = args[1];
  if (!harga) {
    return message.reply('❌ Format salah! Gunakan: `!nominal <harga>`\nContoh: `!nominal 15000`');
  }

  const rawNominal = harga.replace(/\D/g, '');
  const formatted = Number(rawNominal).toLocaleString('id-ID');
  if (!rawNominal || rawNominal === '0') {
    return message.reply('❌ Nominal tidak valid. Contoh: `!nominal 15000`');
  }

  const embed = new EmbedBuilder()
    .setTitle('💰 PEMBAYARAN QRIS')
    .setDescription(
      `Silakan scan QRIS di bawah ini dan bayar sesuai nominal.\n\n` +
      `💵 **Total yang harus dibayar: Rp ${formatted}**\n\n` +
      `Setelah pembayaran, kirim bukti transfer di channel ini.`
    )
    .setImage(QRIS_IMAGE)
    .setColor('#00A86B')
    .setTimestamp();

  // Simpan nominal ke topic channel
  const currentTopic = message.channel.topic || '';
  const newTopic = currentTopic.includes('|NOMINAL:')
    ? currentTopic.replace(/\|NOMINAL:\d+/, `|NOMINAL:${rawNominal}`)
    : `${currentTopic}|NOMINAL:${rawNominal}`;
  await message.channel.setTopic(newTopic).catch(() => {});

  await message.delete().catch(() => {});
  await message.channel.send({ embeds: [embed] });
});

client.on('interactionCreate', async (interaction) => {
  // ================= PANEL =================
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === 'panel') {
      const embed = new EmbedBuilder()
        .setTitle('🛒 LAPAK STORE ID')
        .setDescription(
          'Selamat datang di **Lapak Store ID**! Pilih produk yang kamu inginkan di bawah ini.\n\n' +
          '🎮 **Vilog Robux** — Top up Robux langsung ke akun Roblox kamu dengan cepat dan aman.\n' +
          '⏳ **Robux Pending** — Beli Robux melalui metode pending, cocok untuk yang butuh harga lebih hemat.\n' +
          '🎁 **Gift In Game Roblox** — Kirim gift item in-game ke karakter Roblox tujuan kamu.\n' +
          '🔥 **Top Up FF** — Isi diamond Free Fire dengan cepat, langsung masuk ke akun kamu.\n' +
          '⚡ **Top Up ML** — Top up diamond Mobile Legends, proses kilat dan terpercaya.\n' +
          '💎 **Vilog ML** — Top up diamond ML via login akun Moonton, harga terjangkau.\n\n' +
          '📩 Klik tombol di bawah untuk mulai order!'
        )
        .setColor('#2b2d31');

      const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('vilog_robux').setLabel('Vilog Robux').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('robux_pending').setLabel('Robux Pending').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('gift_roblox').setLabel('Gift In Game Roblox').setStyle(ButtonStyle.Success)
      );

      const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('topup_ff').setLabel('Top Up FF').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('topup_ml').setLabel('Top Up ML').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('vilog_ml').setLabel('Vilog ML').setStyle(ButtonStyle.Secondary)
      );

      return interaction.reply({ embeds: [embed], components: [row1, row2] });
    }
  }

  // ================= BUTTON =================
  if (interaction.isButton()) {
    const allowedRoles = [ROLE_1, ROLE_2];
    const isAdmin = interaction.member?.roles?.cache.some((r) => allowedRoles.includes(r.id)) ?? false;

    // ================= PAID =================
    if (interaction.customId === 'paid_ticket') {
      if (!isAdmin) return interaction.reply({ content: '❌ Tidak ada akses!', ephemeral: true });

      const embed = EmbedBuilder.from(interaction.message.embeds[0]).spliceFields(0, 1, {
        name: 'Status',
        value: '💰 Paid',
        inline: true,
      });

      await interaction.update({ embeds: [embed] });

      const prosesEmbed = new EmbedBuilder()
        .setTitle('⚙️ PESANAN SEDANG DIPROSES')
        .setDescription(
          `Halo 👋\n\n` +
          `Pembayaran kamu telah **berhasil dikonfirmasi** oleh tim kami.\n\n` +
          `Pesanan kamu sedang dalam tahap pemrosesan. Tim kami akan segera menyelesaikan order ini dengan cepat dan aman.\n\n` +
          `⏳ **Mohon bersabar**, proses ini biasanya tidak memakan waktu lama.\n` +
          `📩 Apabila ada pertanyaan, silakan hubungi admin di channel ini.\n\n` +
          `— **Lapak Store ID** 🛒`
        )
        .setColor('#FEE75C')
        .setTimestamp();

      await interaction.channel.send({ embeds: [prosesEmbed] });
      return;
    }

    // ================= DONE =================
    if (interaction.customId === 'selesai_ticket') {
      if (!isAdmin) return interaction.reply({ content: '❌ Tidak ada akses!', ephemeral: true });

      const embed = EmbedBuilder.from(interaction.message.embeds[0]).spliceFields(0, 1, {
        name: 'Status',
        value: '✅ Done',
        inline: true,
      });

      await interaction.update({ embeds: [embed] });

      // Parse topic: ORDER_ID:XXXX|BUYER:userid|NOMINAL:rawNominal
      const topic = interaction.channel.topic || '';
      let orderId = 'Unknown';
      let buyerId = null;
      let nominal = '';

      const topicParts = topic.split('|');
      orderId = (topicParts[0] || '').replace('ORDER_ID:', '') || 'Unknown';
      buyerId = (topicParts[1] || '').replace('BUYER:', '') || null;
      nominal = (topicParts[2] || '').replace('NOMINAL:', '') || '';

      // Log ke channel log
      const logEmbed = new EmbedBuilder()
        .setTitle('✅ TRANSAKSI SELESAI')
        .setColor('#57F287')
        .addFields(
          { name: 'Order ID', value: `#${orderId}`, inline: true },
          { name: 'Admin', value: `${interaction.user}`, inline: true }
        )
        .setTimestamp();

      const logChannel = interaction.guild.channels.cache.get(LOG_CHANNEL);
      if (logChannel?.isTextBased()) await logChannel.send({ embeds: [logEmbed] });

      // Kirim DM ke buyer dengan tombol vouch
      if (buyerId) {
        try {
          const buyer = await client.users.fetch(buyerId);
          const dmEmbed = new EmbedBuilder()
            .setTitle('🎉 Pesanan Kamu Telah Selesai!')
            .setDescription(
              `Halo **${buyer.username}**! 👋\n\n` +
              `Terima kasih sudah berbelanja di **Lapak Store ID** 🛒\n\n` +
              `Order **#${orderId}** kamu telah berhasil diselesaikan oleh tim kami. ` +
              `Kami berharap kamu puas dengan layanan kami!\n\n` +
              `📝 Kami sangat menghargai pendapatmu. Luangkan sebentar waktumu untuk memberikan **vouch / ulasan** pengalaman belanjamu.\n\n` +
              `Klik tombol di bawah untuk memberikan ulasan! ⭐`
            )
            .setColor('#57F287')
            .setFooter({ text: 'Lapak Store ID • Terima kasih sudah mempercayai kami!' })
            .setTimestamp();

          const vouchBtn = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId(`vouch_${interaction.guildId}_${orderId}_${nominal}`)
              .setLabel('⭐ Berikan Vouch')
              .setStyle(ButtonStyle.Success)
          );

          await buyer.send({ embeds: [dmEmbed], components: [vouchBtn] });
        } catch {
          // Buyer mungkin menonaktifkan DM
        }
      }

      setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
      return;
    }

    // ================= CANCEL =================
    if (interaction.customId === 'cancel_ticket') {
      if (!isAdmin) return interaction.reply({ content: '❌ Tidak ada akses!', ephemeral: true });

      const topic = interaction.channel.topic || '';
      const topicParts = topic.split('|');
      const orderId = (topicParts[0] || '').replace('ORDER_ID:', '') || 'Unknown';

      const logEmbed = new EmbedBuilder()
        .setTitle('❌ TRANSAKSI DIBATALKAN')
        .setColor('#ED4245')
        .addFields(
          { name: 'Order ID', value: `#${orderId}`, inline: true },
          { name: 'User', value: `${interaction.user}`, inline: true }
        )
        .setTimestamp();

      const logChannel = interaction.guild.channels.cache.get(LOG_CHANNEL);
      if (logChannel?.isTextBased()) await logChannel.send({ embeds: [logEmbed] });

      await interaction.reply({ content: '❌ Dibatalkan!' });
      setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
      return;
    }

    // ================= VOUCH BUTTON (dari DM) =================
    if (interaction.customId.startsWith('vouch_')) {
      const parts = interaction.customId.split('_');
      const guildId = parts[1];
      const orderId = parts[2];
      const nominal = parts[3] || '';

      const vouchModal = new ModalBuilder()
        .setCustomId(`modal_vouch_${guildId}_${orderId}_${nominal}`)
        .setTitle('⭐ Berikan Vouch')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('vouch_text')
              .setLabel('Ceritakan pengalaman belanjamu')
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder('Contoh: Pelayanan cepat, ramah, barang langsung masuk. Recommended!')
              .setMinLength(10)
              .setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('rating')
              .setLabel('Rating (1-5 bintang)')
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('Masukkan angka 1 sampai 5')
              .setMaxLength(1)
              .setRequired(true)
          )
        );

      await interaction.showModal(vouchModal);
      return;
    }

    // ================= SHOW MODAL =================
    const modal = modals[interaction.customId];
    if (modal) {
      await interaction.showModal(modal);
    }
  }

  // ================= VOUCH MODAL SUBMIT =================
  if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_vouch_')) {
    const parts = interaction.customId.replace('modal_vouch_', '').split('_');
    const guildId = parts[0];
    const orderId = parts[1];
    const rawNominal = parts[2] || '';
    const formattedNominal = rawNominal
      ? `Rp ${Number(rawNominal).toLocaleString('id-ID')}`
      : '-';

    const vouchText = interaction.fields.getTextInputValue('vouch_text');
    const rawRating = interaction.fields.getTextInputValue('rating').trim();
    const ratingNum = Math.min(5, Math.max(1, parseInt(rawRating) || 5));
    const stars = '⭐'.repeat(ratingNum) + '✩'.repeat(5 - ratingNum);

    const buyer = interaction.user;
    const avatarUrl = buyer.displayAvatarURL({ size: 256 });

    const vouchEmbed = new EmbedBuilder()
      .setAuthor({ name: buyer.username, iconURL: avatarUrl })
      .setTitle('⭐ VOUCH BARU — LAPAK STORE ID')
      .setDescription(`*"${vouchText}"*`)
      .setThumbnail(avatarUrl)
      .setColor('#FFD700')
      .addFields(
        { name: '👤 Pembeli', value: `${buyer}`, inline: true },
        { name: '📦 Order ID', value: `#${orderId}`, inline: true },
        { name: '💵 Nominal', value: formattedNominal, inline: true },
        { name: '🌟 Rating', value: stars, inline: false }
      )
      .setFooter({ text: 'Lapak Store ID • Dipercaya, Cepat & Aman 🛒' })
      .setTimestamp();

    try {
      const guild = await client.guilds.fetch(guildId);
      const vouchCh = await guild.channels.fetch(VOUCH_CHANNEL);
      if (vouchCh?.isTextBased()) await vouchCh.send({ embeds: [vouchEmbed] });
    } catch {
      // Ignore jika channel tidak ditemukan
    }

    await interaction.reply({
      content: '✅ Terima kasih! Vouch kamu sudah dikirim. Sampai jumpa di order berikutnya! 🎉',
      ephemeral: true,
    });

    await interaction.message?.edit({ components: [] }).catch(() => {});
    return;
  }

  // ================= MODAL SUBMIT (ORDER) =================
  if (interaction.isModalSubmit()) {
    const orderId = getOrderNumber();
    const username = interaction.user.username;
    const modalId = interaction.customId;
    const productName = PRODUCT_NAMES[modalId] || 'Produk';

    const fields = {};
    for (const row of interaction.components) {
      for (const component of row.components) {
        fields[component.customId] = component.value || '-';
      }
    }

    const orderFields = getOrderFields(modalId, fields);

    const channel = await interaction.guild.channels.create({
      name: `lapak-${username}-${orderId}`,
      type: ChannelType.GuildText,
      parent: CATEGORY_ID,
      topic: `ORDER_ID:${orderId}|BUYER:${interaction.user.id}`,
      permissionOverwrites: [
        { id: interaction.guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel] },
        { id: ROLE_1, allow: [PermissionsBitField.Flags.ViewChannel] },
        { id: ROLE_2, allow: [PermissionsBitField.Flags.ViewChannel] },
      ],
    });

    const embed = new EmbedBuilder()
      .setTitle(`📦 ORDER #${orderId}`)
      .setColor('#2b2d31')
      .addFields(
        { name: 'Status', value: '🟡 Pending', inline: true },
        { name: 'Produk', value: productName, inline: true },
        { name: 'Pembeli', value: `${interaction.user}`, inline: true },
        ...orderFields
      )
      .setTimestamp();

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('paid_ticket').setLabel('Paid').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('selesai_ticket').setLabel('Selesai').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('cancel_ticket').setLabel('Cancel').setStyle(ButtonStyle.Danger)
    );

    await channel.send({
      content: `<@&${ROLE_1}> <@&${ROLE_2}>`,
      embeds: [embed],
      components: [buttons],
    });

    await interaction.reply({ content: `✅ Ticket dibuat: ${channel}`, ephemeral: true });
  }
});

const token = process.env.DISCORD_TOKEN;
if (!token) throw new Error('DISCORD_TOKEN tidak ditemukan di file .env');
client.login(token);

// Web server agar terdeteksi sebagai aplikasi web oleh hosting platform
const PORT = process.env.PORT || 3000;
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`
    <html>
      <head><title>Lapak Store ID</title></head>
      <body style="font-family:sans-serif;text-align:center;padding:50px;background:#2b2d31;color:#fff">
        <h1>🛒 Lapak Store ID</h1>
        <p>Bot Discord sedang berjalan.</p>
        <p style="color:#57F287">✅ Online</p>
      </body>
    </html>
  `);
});
server.listen(PORT, () => {
  console.log(`Web server berjalan di port ${PORT}`);
});
