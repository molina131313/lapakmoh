# Lapak Store ID — Discord Bot

Bot Discord untuk toko top-up game. Dibuat dengan JavaScript murni (Node.js), tanpa TypeScript, siap deploy ke VPS manapun.

## Cara Setup

### 1. Install dependencies
```
npm install
```

### 2. Buat file .env
Salin file `.env.example` menjadi `.env`, lalu isi nilainya:
```
cp .env.example .env
```

Isi file `.env`:
```
DISCORD_TOKEN=token_bot_kamu_disini
CLIENT_ID=1486570490934984875
GUILD_ID=
```
- `DISCORD_TOKEN` — Token bot dari Discord Developer Portal
- `CLIENT_ID` — ID aplikasi bot kamu (sudah terisi)
- `GUILD_ID` — Kosongkan untuk daftar command secara global, atau isi ID server untuk lebih cepat

### 3. Daftarkan slash command /panel
```
npm run deploy
```

### 4. Jalankan bot
```
npm start
```

---

## Fitur

- `/panel` — Menampilkan panel produk dengan 6 tombol (Vilog Robux, Robux Pending, Gift In Game Roblox, Top Up FF, Top Up ML, Vilog ML)
- Setiap tombol membuka form pemesanan
- Ticket otomatis dibuat untuk setiap order
- `!nominal <harga>` — Admin kirim QRIS dengan nominal spesifik
- Tombol **Paid / Selesai / Cancel** untuk admin
- DM otomatis ke buyer saat order selesai + tombol vouch
- Vouch terkirim ke channel vouch dengan tampilan profesional

---

## Struktur File

```
lapak-store-bot/
├── index.js          — Bot utama
├── deploy-commands.js — Daftarkan slash command
├── package.json
├── order.json        — Counter nomor order (jangan dihapus)
├── .env              — Token & konfigurasi (buat sendiri dari .env.example)
└── .env.example      — Contoh konfigurasi
```
